package net.mcreator.yetsomeotherbackroomsmod.client.model;

import net.minecraft.world.entity.Entity;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.EntityModel;

import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.PoseStack;

// Made with Blockbench 4.9.4
// Exported for Minecraft version 1.17 or later with Mojang mappings
// Paste this class into your mod and generate all required imports
public class ModelSkinStealer<T extends Entity> extends EntityModel<T> {
	// This layer location should be baked with EntityRendererProvider.Context in
	// the entity renderer and passed into this model's constructor
	public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(new ResourceLocation("yetsomeotherbackroomsmod", "model_skin_stealer"), "main");
	public final ModelPart fullbody;

	public ModelSkinStealer(ModelPart root) {
		this.fullbody = root.getChild("fullbody");
	}

	public static LayerDefinition createBodyLayer() {
		MeshDefinition meshdefinition = new MeshDefinition();
		PartDefinition partdefinition = meshdefinition.getRoot();
		PartDefinition fullbody = partdefinition.addOrReplaceChild("fullbody", CubeListBuilder.create(), PartPose.offset(0.0F, 5.0F, 0.0F));
		PartDefinition head = fullbody.addOrReplaceChild("head", CubeListBuilder.create(), PartPose.offset(0.0F, 0.0F, 0.0F));
		PartDefinition head_r1 = head.addOrReplaceChild("head_r1", CubeListBuilder.create().texOffs(0, 12).addBox(-2.0F, -12.25F, -0.9873F, 4.0F, 6.0F, 3.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 9.25F, -0.5127F, 0.0F, 0.0F, 0.0F));
		PartDefinition body = fullbody.addOrReplaceChild("body", CubeListBuilder.create(), PartPose.offset(0.0F, 9.25F, -0.5127F));
		PartDefinition body_r1 = body.addOrReplaceChild("body_r1", CubeListBuilder.create().texOffs(0, 0).addBox(-3.0F, -6.25F, -1.4873F, 6.0F, 8.0F, 4.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
		PartDefinition left_arm = fullbody.addOrReplaceChild("left_arm", CubeListBuilder.create(), PartPose.offset(5.3345F, 12.6446F, 0.4481F));
		PartDefinition cube_r1 = left_arm.addOrReplaceChild("cube_r1",
				CubeListBuilder.create().texOffs(21, 22).addBox(3.4765F, -4.5822F, 0.5127F, 1.0F, 10.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(6, 21).addBox(3.4765F, 5.4178F, 0.5127F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-5.3345F, -3.3946F, -0.9607F, 0.0F, 0.0F, -0.2618F));
		PartDefinition bone7 = left_arm.addOrReplaceChild("bone7", CubeListBuilder.create(), PartPose.offset(0.9228F, 2.3341F, 1.0266F));
		PartDefinition cube_r2 = bone7.addOrReplaceChild("cube_r2", CubeListBuilder.create().texOffs(16, 20).addBox(-1.8686F, 7.4584F, 1.0826F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-6.2574F, -5.7288F, -1.9873F, 2.5307F, -0.6545F, 2.7053F));
		PartDefinition bone6 = left_arm.addOrReplaceChild("bone6", CubeListBuilder.create(), PartPose.offset(1.0401F, 2.2794F, 0.0519F));
		PartDefinition cube_r3 = bone6.addOrReplaceChild("cube_r3", CubeListBuilder.create().texOffs(24, 20).addBox(-0.749F, 7.5305F, 0.5127F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-6.3747F, -5.6741F, -1.0127F, 0.0F, 0.0F, -0.8727F));
		PartDefinition bone5 = left_arm.addOrReplaceChild("bone5", CubeListBuilder.create(), PartPose.offset(0.7697F, 2.1346F, -1.2344F));
		PartDefinition cube_r4 = bone5.addOrReplaceChild("cube_r4", CubeListBuilder.create().texOffs(11, 12).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, -0.6109F, -0.6545F, -0.4363F));
		PartDefinition right_arm = fullbody.addOrReplaceChild("right_arm", CubeListBuilder.create(), PartPose.offset(-5.3345F, 12.6446F, 0.4481F));
		PartDefinition cube_r5 = right_arm.addOrReplaceChild("cube_r5", CubeListBuilder.create().texOffs(20, 8).addBox(-4.4765F, 5.4178F, 0.5127F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(5.3345F, -3.3946F, -0.9607F, 0.0F, 0.0F, 0.2618F));
		PartDefinition cube_r6 = right_arm.addOrReplaceChild("cube_r6", CubeListBuilder.create().texOffs(21, 22).mirror().addBox(-4.5F, -4.25F, 0.5127F, 1.0F, 10.0F, 1.0F, new CubeDeformation(0.0F)).mirror(false),
				PartPose.offsetAndRotation(5.3345F, -3.3946F, -0.9607F, 0.0F, 0.0F, 0.2618F));
		PartDefinition bone8 = right_arm.addOrReplaceChild("bone8", CubeListBuilder.create(), PartPose.offset(-0.0491F, -0.0079F, 0.072F));
		PartDefinition cube_r7 = bone8.addOrReplaceChild("cube_r7", CubeListBuilder.create().texOffs(0, 0).addBox(-0.3337F, -1.0F, -0.5F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-1.0757F, 1.9592F, -0.9482F, 2.3821F, -0.4598F, 1.1511F));
		PartDefinition bone10 = right_arm.addOrReplaceChild("bone10", CubeListBuilder.create(), PartPose.offset(-0.0491F, -0.0079F, 0.072F));
		PartDefinition cube_r8 = bone10.addOrReplaceChild("cube_r8", CubeListBuilder.create().texOffs(7, 26).addBox(0.8686F, 7.4584F, 1.0826F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(5.3836F, -3.3868F, -1.0327F, 2.5307F, 0.6545F, -2.7053F));
		PartDefinition bone9 = right_arm.addOrReplaceChild("bone9", CubeListBuilder.create(), PartPose.offset(-1.0401F, 2.2794F, 0.0519F));
		PartDefinition cube_r9 = bone9.addOrReplaceChild("cube_r9", CubeListBuilder.create().texOffs(16, 0).addBox(-0.251F, 7.5305F, 0.5127F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(6.3747F, -5.6741F, -1.0127F, 0.0F, 0.0F, 0.8727F));
		PartDefinition bone4 = fullbody.addOrReplaceChild("bone4", CubeListBuilder.create(), PartPose.offset(0.0F, 9.25F, -0.5127F));
		PartDefinition downleft_r1 = bone4.addOrReplaceChild("downleft_r1", CubeListBuilder.create().texOffs(0, 21).addBox(1.0F, 5.75F, -0.4873F, 2.0F, 4.0F, 2.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
		PartDefinition bone3 = fullbody.addOrReplaceChild("bone3", CubeListBuilder.create(), PartPose.offset(-2.0F, 17.0F, 0.0F));
		PartDefinition downright_r1 = bone3.addOrReplaceChild("downright_r1", CubeListBuilder.create().texOffs(23, 8).addBox(-3.0F, 5.75F, -0.4873F, 2.0F, 4.0F, 2.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(2.0F, -7.75F, -0.5127F, 0.0F, 0.0F, 0.0F));
		PartDefinition bone2 = fullbody.addOrReplaceChild("bone2", CubeListBuilder.create(), PartPose.offset(0.0F, 9.25F, -0.5127F));
		PartDefinition upright_r1 = bone2.addOrReplaceChild("upright_r1", CubeListBuilder.create().texOffs(25, 26).addBox(-3.0F, 1.75F, -0.4873F, 2.0F, 4.0F, 2.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
		PartDefinition bone = fullbody.addOrReplaceChild("bone", CubeListBuilder.create(), PartPose.offset(0.0F, 9.25F, -0.5127F));
		PartDefinition upleft_r1 = bone.addOrReplaceChild("upleft_r1", CubeListBuilder.create().texOffs(26, 14).addBox(1.0F, 1.75F, -0.4873F, 2.0F, 4.0F, 2.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
		return LayerDefinition.create(meshdefinition, 64, 64);
	}

	@Override
	public void renderToBuffer(PoseStack poseStack, VertexConsumer vertexConsumer, int packedLight, int packedOverlay, float red, float green, float blue, float alpha) {
		fullbody.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
	}

	public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
	}
}
