
package net.mcreator.yetsomeotherbackroomsmod.client.screens;

import org.checkerframework.checker.units.qual.h;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.client.event.RenderGuiEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.Minecraft;

import net.mcreator.yetsomeotherbackroomsmod.procedures.ThirstBarHalfDisplayCondition9Procedure;
import net.mcreator.yetsomeotherbackroomsmod.procedures.ThirstBarHalfDisplayCondition8Procedure;
import net.mcreator.yetsomeotherbackroomsmod.procedures.ThirstBarHalfDisplayCondition7Procedure;
import net.mcreator.yetsomeotherbackroomsmod.procedures.ThirstBarHalfDisplayCondition4Procedure;
import net.mcreator.yetsomeotherbackroomsmod.procedures.ThirstBarHalfDisplayCondition3Procedure;
import net.mcreator.yetsomeotherbackroomsmod.procedures.ThirstBarHalfDisplayCondition2Procedure;
import net.mcreator.yetsomeotherbackroomsmod.procedures.ThirstBarHalfDisplayCondition1Procedure;
import net.mcreator.yetsomeotherbackroomsmod.procedures.ThirstBarHalfDisplayCondition10Procedure;
import net.mcreator.yetsomeotherbackroomsmod.procedures.ThirstBarHalfDisplay6Procedure;
import net.mcreator.yetsomeotherbackroomsmod.procedures.ThirstBarHalfDisplay5Procedure;
import net.mcreator.yetsomeotherbackroomsmod.procedures.ThirstBarFullDisplayCondition9Procedure;
import net.mcreator.yetsomeotherbackroomsmod.procedures.ThirstBarFullDisplayCondition8Procedure;
import net.mcreator.yetsomeotherbackroomsmod.procedures.ThirstBarFullDisplayCondition7Procedure;
import net.mcreator.yetsomeotherbackroomsmod.procedures.ThirstBarFullDisplayCondition6Procedure;
import net.mcreator.yetsomeotherbackroomsmod.procedures.ThirstBarFullDisplayCondition4Procedure;
import net.mcreator.yetsomeotherbackroomsmod.procedures.ThirstBarFullDisplayCondition3Procedure;
import net.mcreator.yetsomeotherbackroomsmod.procedures.ThirstBarFullDisplayCondition2Procedure;
import net.mcreator.yetsomeotherbackroomsmod.procedures.ThirstBarFullDisplayCondition1Procedure;
import net.mcreator.yetsomeotherbackroomsmod.procedures.ThirstBarFullDisplayCondition10Procedure;
import net.mcreator.yetsomeotherbackroomsmod.procedures.ThirstBarFullDisplay5Procedure;
import net.mcreator.yetsomeotherbackroomsmod.procedures.ShowThirstBarProcedureProcedure;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.platform.GlStateManager;

@Mod.EventBusSubscriber({Dist.CLIENT})
public class ThirstBarOverlay {
	@SubscribeEvent(priority = EventPriority.NORMAL)
	public static void eventHandler(RenderGuiEvent.Pre event) {
		int w = event.getWindow().getGuiScaledWidth();
		int h = event.getWindow().getGuiScaledHeight();
		Level world = null;
		double x = 0;
		double y = 0;
		double z = 0;
		Player entity = Minecraft.getInstance().player;
		if (entity != null) {
			world = entity.level();
			x = entity.getX();
			y = entity.getY();
			z = entity.getZ();
		}
		RenderSystem.disableDepthTest();
		RenderSystem.depthMask(false);
		RenderSystem.enableBlend();
		RenderSystem.setShader(GameRenderer::getPositionTexShader);
		RenderSystem.blendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
		RenderSystem.setShaderColor(1, 1, 1, 1);
		if (ShowThirstBarProcedureProcedure.execute(entity)) {
			event.getGuiGraphics().blit(new ResourceLocation("yetsomeotherbackroomsmod:textures/screens/empty.png"), w / 2 + 9, h / 2 + 78, 0, 0, 8, 8, 8, 8);

			if (ThirstBarHalfDisplayCondition10Procedure.execute(entity)) {
				event.getGuiGraphics().blit(new ResourceLocation("yetsomeotherbackroomsmod:textures/screens/half.png"), w / 2 + 9, h / 2 + 78, 0, 0, 8, 8, 8, 8);
			}
			if (ThirstBarFullDisplayCondition10Procedure.execute(entity)) {
				event.getGuiGraphics().blit(new ResourceLocation("yetsomeotherbackroomsmod:textures/screens/full.png"), w / 2 + 9, h / 2 + 78, 0, 0, 8, 8, 8, 8);
			}
			event.getGuiGraphics().blit(new ResourceLocation("yetsomeotherbackroomsmod:textures/screens/empty.png"), w / 2 + 17, h / 2 + 78, 0, 0, 8, 8, 8, 8);

			if (ThirstBarHalfDisplayCondition9Procedure.execute(entity)) {
				event.getGuiGraphics().blit(new ResourceLocation("yetsomeotherbackroomsmod:textures/screens/half.png"), w / 2 + 17, h / 2 + 78, 0, 0, 8, 8, 8, 8);
			}
			if (ThirstBarFullDisplayCondition9Procedure.execute(entity)) {
				event.getGuiGraphics().blit(new ResourceLocation("yetsomeotherbackroomsmod:textures/screens/full.png"), w / 2 + 17, h / 2 + 78, 0, 0, 8, 8, 8, 8);
			}
			event.getGuiGraphics().blit(new ResourceLocation("yetsomeotherbackroomsmod:textures/screens/empty.png"), w / 2 + 25, h / 2 + 78, 0, 0, 8, 8, 8, 8);

			if (ThirstBarHalfDisplayCondition8Procedure.execute(entity)) {
				event.getGuiGraphics().blit(new ResourceLocation("yetsomeotherbackroomsmod:textures/screens/half.png"), w / 2 + 25, h / 2 + 78, 0, 0, 8, 8, 8, 8);
			}
			if (ThirstBarFullDisplayCondition8Procedure.execute(entity)) {
				event.getGuiGraphics().blit(new ResourceLocation("yetsomeotherbackroomsmod:textures/screens/full.png"), w / 2 + 25, h / 2 + 78, 0, 0, 8, 8, 8, 8);
			}
			event.getGuiGraphics().blit(new ResourceLocation("yetsomeotherbackroomsmod:textures/screens/empty.png"), w / 2 + 33, h / 2 + 78, 0, 0, 8, 8, 8, 8);

			if (ThirstBarHalfDisplayCondition7Procedure.execute(entity)) {
				event.getGuiGraphics().blit(new ResourceLocation("yetsomeotherbackroomsmod:textures/screens/half.png"), w / 2 + 33, h / 2 + 78, 0, 0, 8, 8, 8, 8);
			}
			if (ThirstBarFullDisplayCondition7Procedure.execute(entity)) {
				event.getGuiGraphics().blit(new ResourceLocation("yetsomeotherbackroomsmod:textures/screens/full.png"), w / 2 + 33, h / 2 + 78, 0, 0, 8, 8, 8, 8);
			}
			event.getGuiGraphics().blit(new ResourceLocation("yetsomeotherbackroomsmod:textures/screens/empty.png"), w / 2 + 41, h / 2 + 78, 0, 0, 8, 8, 8, 8);

			if (ThirstBarHalfDisplay6Procedure.execute(entity)) {
				event.getGuiGraphics().blit(new ResourceLocation("yetsomeotherbackroomsmod:textures/screens/half.png"), w / 2 + 41, h / 2 + 78, 0, 0, 8, 8, 8, 8);
			}
			if (ThirstBarFullDisplayCondition6Procedure.execute(entity)) {
				event.getGuiGraphics().blit(new ResourceLocation("yetsomeotherbackroomsmod:textures/screens/full.png"), w / 2 + 41, h / 2 + 78, 0, 0, 8, 8, 8, 8);
			}
			event.getGuiGraphics().blit(new ResourceLocation("yetsomeotherbackroomsmod:textures/screens/empty.png"), w / 2 + 49, h / 2 + 78, 0, 0, 8, 8, 8, 8);

			if (ThirstBarHalfDisplay5Procedure.execute(entity)) {
				event.getGuiGraphics().blit(new ResourceLocation("yetsomeotherbackroomsmod:textures/screens/half.png"), w / 2 + 49, h / 2 + 78, 0, 0, 8, 8, 8, 8);
			}
			if (ThirstBarFullDisplay5Procedure.execute(entity)) {
				event.getGuiGraphics().blit(new ResourceLocation("yetsomeotherbackroomsmod:textures/screens/full.png"), w / 2 + 49, h / 2 + 78, 0, 0, 8, 8, 8, 8);
			}
			event.getGuiGraphics().blit(new ResourceLocation("yetsomeotherbackroomsmod:textures/screens/empty.png"), w / 2 + 57, h / 2 + 78, 0, 0, 8, 8, 8, 8);

			if (ThirstBarHalfDisplayCondition4Procedure.execute(entity)) {
				event.getGuiGraphics().blit(new ResourceLocation("yetsomeotherbackroomsmod:textures/screens/half.png"), w / 2 + 57, h / 2 + 78, 0, 0, 8, 8, 8, 8);
			}
			if (ThirstBarFullDisplayCondition4Procedure.execute(entity)) {
				event.getGuiGraphics().blit(new ResourceLocation("yetsomeotherbackroomsmod:textures/screens/full.png"), w / 2 + 57, h / 2 + 78, 0, 0, 8, 8, 8, 8);
			}
			event.getGuiGraphics().blit(new ResourceLocation("yetsomeotherbackroomsmod:textures/screens/empty.png"), w / 2 + 65, h / 2 + 78, 0, 0, 8, 8, 8, 8);

			if (ThirstBarHalfDisplayCondition3Procedure.execute(entity)) {
				event.getGuiGraphics().blit(new ResourceLocation("yetsomeotherbackroomsmod:textures/screens/half.png"), w / 2 + 65, h / 2 + 78, 0, 0, 8, 8, 8, 8);
			}
			if (ThirstBarFullDisplayCondition3Procedure.execute(entity)) {
				event.getGuiGraphics().blit(new ResourceLocation("yetsomeotherbackroomsmod:textures/screens/full.png"), w / 2 + 65, h / 2 + 78, 0, 0, 8, 8, 8, 8);
			}
			event.getGuiGraphics().blit(new ResourceLocation("yetsomeotherbackroomsmod:textures/screens/empty.png"), w / 2 + 73, h / 2 + 78, 0, 0, 8, 8, 8, 8);

			if (ThirstBarHalfDisplayCondition2Procedure.execute(entity)) {
				event.getGuiGraphics().blit(new ResourceLocation("yetsomeotherbackroomsmod:textures/screens/half.png"), w / 2 + 73, h / 2 + 78, 0, 0, 8, 8, 8, 8);
			}
			if (ThirstBarFullDisplayCondition2Procedure.execute(entity)) {
				event.getGuiGraphics().blit(new ResourceLocation("yetsomeotherbackroomsmod:textures/screens/full.png"), w / 2 + 73, h / 2 + 78, 0, 0, 8, 8, 8, 8);
			}
			event.getGuiGraphics().blit(new ResourceLocation("yetsomeotherbackroomsmod:textures/screens/empty.png"), w / 2 + 81, h / 2 + 78, 0, 0, 8, 8, 8, 8);

			if (ThirstBarHalfDisplayCondition1Procedure.execute(entity)) {
				event.getGuiGraphics().blit(new ResourceLocation("yetsomeotherbackroomsmod:textures/screens/half.png"), w / 2 + 81, h / 2 + 78, 0, 0, 8, 8, 8, 8);
			}
			if (ThirstBarFullDisplayCondition1Procedure.execute(entity)) {
				event.getGuiGraphics().blit(new ResourceLocation("yetsomeotherbackroomsmod:textures/screens/full.png"), w / 2 + 81, h / 2 + 78, 0, 0, 8, 8, 8, 8);
			}
		}
		RenderSystem.depthMask(true);
		RenderSystem.defaultBlendFunc();
		RenderSystem.enableDepthTest();
		RenderSystem.disableBlend();
		RenderSystem.setShaderColor(1, 1, 1, 1);
	}
}
