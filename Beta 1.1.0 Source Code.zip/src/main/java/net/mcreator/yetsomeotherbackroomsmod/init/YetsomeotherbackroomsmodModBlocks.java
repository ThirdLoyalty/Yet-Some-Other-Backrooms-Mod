
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.yetsomeotherbackroomsmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.yetsomeotherbackroomsmod.block.SolidGlitchBlockBlock;
import net.mcreator.yetsomeotherbackroomsmod.block.PoolroomsTileBlock;
import net.mcreator.yetsomeotherbackroomsmod.block.PartyFloorBlock;
import net.mcreator.yetsomeotherbackroomsmod.block.MetalPipeBarsBlock;
import net.mcreator.yetsomeotherbackroomsmod.block.MetalBlockBlock;
import net.mcreator.yetsomeotherbackroomsmod.block.LootBarrelBlock;
import net.mcreator.yetsomeotherbackroomsmod.block.LevelRunLightBlock;
import net.mcreator.yetsomeotherbackroomsmod.block.Level4WallBlock;
import net.mcreator.yetsomeotherbackroomsmod.block.Level4Wall2Block;
import net.mcreator.yetsomeotherbackroomsmod.block.Level4LightBlock;
import net.mcreator.yetsomeotherbackroomsmod.block.Level1PillarBlock;
import net.mcreator.yetsomeotherbackroomsmod.block.Level0WallBlock;
import net.mcreator.yetsomeotherbackroomsmod.block.Level0LightBlock;
import net.mcreator.yetsomeotherbackroomsmod.block.Level0FloorBlock;
import net.mcreator.yetsomeotherbackroomsmod.block.Level0DirtyFloorBlock;
import net.mcreator.yetsomeotherbackroomsmod.block.Level0CeilingBlock;
import net.mcreator.yetsomeotherbackroomsmod.block.Level0BottomWallBlock;
import net.mcreator.yetsomeotherbackroomsmod.block.IronVentBlock;
import net.mcreator.yetsomeotherbackroomsmod.block.GlitchBlockBlock;
import net.mcreator.yetsomeotherbackroomsmod.block.DarkerPoolroomsTileBlock;
import net.mcreator.yetsomeotherbackroomsmod.block.CopperPipeBlock;
import net.mcreator.yetsomeotherbackroomsmod.block.ConnectedCopperPipeBlock;
import net.mcreator.yetsomeotherbackroomsmod.YetsomeotherbackroomsmodMod;

public class YetsomeotherbackroomsmodModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, YetsomeotherbackroomsmodMod.MODID);
	public static final RegistryObject<Block> LEVEL_0_BOTTOM_WALL = REGISTRY.register("level_0_bottom_wall", () -> new Level0BottomWallBlock());
	public static final RegistryObject<Block> LEVEL_0_WALL = REGISTRY.register("level_0_wall", () -> new Level0WallBlock());
	public static final RegistryObject<Block> LEVEL_0_FLOOR = REGISTRY.register("level_0_floor", () -> new Level0FloorBlock());
	public static final RegistryObject<Block> LEVEL_0_CEILING = REGISTRY.register("level_0_ceiling", () -> new Level0CeilingBlock());
	public static final RegistryObject<Block> LEVEL_0_LIGHT = REGISTRY.register("level_0_light", () -> new Level0LightBlock());
	public static final RegistryObject<Block> LOOT_BARREL = REGISTRY.register("loot_barrel", () -> new LootBarrelBlock());
	public static final RegistryObject<Block> IRON_VENT = REGISTRY.register("iron_vent", () -> new IronVentBlock());
	public static final RegistryObject<Block> LEVEL_RUN_LIGHT = REGISTRY.register("level_run_light", () -> new LevelRunLightBlock());
	public static final RegistryObject<Block> POOLROOMS_TILE = REGISTRY.register("poolrooms_tile", () -> new PoolroomsTileBlock());
	public static final RegistryObject<Block> LEVEL_0_DIRTY_FLOOR = REGISTRY.register("level_0_dirty_floor", () -> new Level0DirtyFloorBlock());
	public static final RegistryObject<Block> METAL_BLOCK = REGISTRY.register("metal_block", () -> new MetalBlockBlock());
	public static final RegistryObject<Block> METAL_PIPE_BARS = REGISTRY.register("metal_pipe_bars", () -> new MetalPipeBarsBlock());
	public static final RegistryObject<Block> LEVEL_4_WALL = REGISTRY.register("level_4_wall", () -> new Level4WallBlock());
	public static final RegistryObject<Block> LEVEL_4_LIGHT = REGISTRY.register("level_4_light", () -> new Level4LightBlock());
	public static final RegistryObject<Block> LEVEL_4_WALL_2 = REGISTRY.register("level_4_wall_2", () -> new Level4Wall2Block());
	public static final RegistryObject<Block> LEVEL_1_PILLAR = REGISTRY.register("level_1_pillar", () -> new Level1PillarBlock());
	public static final RegistryObject<Block> DARKER_POOLROOMS_TILE = REGISTRY.register("darker_poolrooms_tile", () -> new DarkerPoolroomsTileBlock());
	public static final RegistryObject<Block> PARTY_FLOOR = REGISTRY.register("party_floor", () -> new PartyFloorBlock());
	public static final RegistryObject<Block> GLITCH_BLOCK = REGISTRY.register("glitch_block", () -> new GlitchBlockBlock());
	public static final RegistryObject<Block> SOLID_GLITCH_BLOCK = REGISTRY.register("solid_glitch_block", () -> new SolidGlitchBlockBlock());
	public static final RegistryObject<Block> COPPER_PIPE = REGISTRY.register("copper_pipe", () -> new CopperPipeBlock());
	public static final RegistryObject<Block> CONNECTED_COPPER_PIPE = REGISTRY.register("connected_copper_pipe", () -> new ConnectedCopperPipeBlock());
	// Start of user code block custom blocks
	// End of user code block custom blocks
}
