
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.yetsomeotherbackroomsmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;

import net.mcreator.yetsomeotherbackroomsmod.entity.LiquidPainEntityEntity;
import net.mcreator.yetsomeotherbackroomsmod.YetsomeotherbackroomsmodMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class YetsomeotherbackroomsmodModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, YetsomeotherbackroomsmodMod.MODID);
	public static final RegistryObject<EntityType<LiquidPainEntityEntity>> LIQUID_PAIN_ENTITY = register("liquid_pain_entity", EntityType.Builder.<LiquidPainEntityEntity>of(LiquidPainEntityEntity::new, MobCategory.MISC)
			.setCustomClientFactory(LiquidPainEntityEntity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));

	private static <T extends Entity> RegistryObject<EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(registryname));
	}
}
