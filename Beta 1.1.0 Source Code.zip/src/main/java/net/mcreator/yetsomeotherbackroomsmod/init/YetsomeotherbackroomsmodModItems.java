
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.yetsomeotherbackroomsmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.yetsomeotherbackroomsmod.item.TannedLeatherItem;
import net.mcreator.yetsomeotherbackroomsmod.item.RockItem;
import net.mcreator.yetsomeotherbackroomsmod.item.PurifiedWaterBottleItem;
import net.mcreator.yetsomeotherbackroomsmod.item.LiquidPainItem;
import net.mcreator.yetsomeotherbackroomsmod.item.EmptyAlmondWaterCanItem;
import net.mcreator.yetsomeotherbackroomsmod.item.CrowbarItem;
import net.mcreator.yetsomeotherbackroomsmod.item.BackpackItem;
import net.mcreator.yetsomeotherbackroomsmod.item.AlmondWaterItem;
import net.mcreator.yetsomeotherbackroomsmod.YetsomeotherbackroomsmodMod;

public class YetsomeotherbackroomsmodModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, YetsomeotherbackroomsmodMod.MODID);
	public static final RegistryObject<Item> LEVEL_0_BOTTOM_WALL = block(YetsomeotherbackroomsmodModBlocks.LEVEL_0_BOTTOM_WALL);
	public static final RegistryObject<Item> LEVEL_0_WALL = block(YetsomeotherbackroomsmodModBlocks.LEVEL_0_WALL);
	public static final RegistryObject<Item> LEVEL_0_FLOOR = block(YetsomeotherbackroomsmodModBlocks.LEVEL_0_FLOOR);
	public static final RegistryObject<Item> LEVEL_0_CEILING = block(YetsomeotherbackroomsmodModBlocks.LEVEL_0_CEILING);
	public static final RegistryObject<Item> LEVEL_0_LIGHT = block(YetsomeotherbackroomsmodModBlocks.LEVEL_0_LIGHT);
	public static final RegistryObject<Item> LOOT_BARREL = block(YetsomeotherbackroomsmodModBlocks.LOOT_BARREL);
	public static final RegistryObject<Item> IRON_VENT = block(YetsomeotherbackroomsmodModBlocks.IRON_VENT);
	public static final RegistryObject<Item> LEVEL_RUN_LIGHT = block(YetsomeotherbackroomsmodModBlocks.LEVEL_RUN_LIGHT);
	public static final RegistryObject<Item> POOLROOMS_TILE = block(YetsomeotherbackroomsmodModBlocks.POOLROOMS_TILE);
	public static final RegistryObject<Item> LEVEL_0_DIRTY_FLOOR = block(YetsomeotherbackroomsmodModBlocks.LEVEL_0_DIRTY_FLOOR);
	public static final RegistryObject<Item> METAL_BLOCK = block(YetsomeotherbackroomsmodModBlocks.METAL_BLOCK);
	public static final RegistryObject<Item> METAL_PIPE_BARS = block(YetsomeotherbackroomsmodModBlocks.METAL_PIPE_BARS);
	public static final RegistryObject<Item> LEVEL_4_WALL = block(YetsomeotherbackroomsmodModBlocks.LEVEL_4_WALL);
	public static final RegistryObject<Item> LEVEL_4_LIGHT = block(YetsomeotherbackroomsmodModBlocks.LEVEL_4_LIGHT);
	public static final RegistryObject<Item> LEVEL_4_WALL_2 = block(YetsomeotherbackroomsmodModBlocks.LEVEL_4_WALL_2);
	public static final RegistryObject<Item> LEVEL_1_PILLAR = block(YetsomeotherbackroomsmodModBlocks.LEVEL_1_PILLAR);
	public static final RegistryObject<Item> DARKER_POOLROOMS_TILE = block(YetsomeotherbackroomsmodModBlocks.DARKER_POOLROOMS_TILE);
	public static final RegistryObject<Item> PARTY_FLOOR = block(YetsomeotherbackroomsmodModBlocks.PARTY_FLOOR);
	public static final RegistryObject<Item> ALMOND_WATER = REGISTRY.register("almond_water", () -> new AlmondWaterItem());
	public static final RegistryObject<Item> EMPTY_ALMOND_WATER_CAN = REGISTRY.register("empty_almond_water_can", () -> new EmptyAlmondWaterCanItem());
	public static final RegistryObject<Item> LIQUID_PAIN = REGISTRY.register("liquid_pain", () -> new LiquidPainItem());
	public static final RegistryObject<Item> CROWBAR = REGISTRY.register("crowbar", () -> new CrowbarItem());
	public static final RegistryObject<Item> ROCK = REGISTRY.register("rock", () -> new RockItem());
	public static final RegistryObject<Item> PURIFIED_WATER_BOTTLE = REGISTRY.register("purified_water_bottle", () -> new PurifiedWaterBottleItem());
	public static final RegistryObject<Item> GLITCH_BLOCK = block(YetsomeotherbackroomsmodModBlocks.GLITCH_BLOCK);
	public static final RegistryObject<Item> SOLID_GLITCH_BLOCK = block(YetsomeotherbackroomsmodModBlocks.SOLID_GLITCH_BLOCK);
	public static final RegistryObject<Item> COPPER_PIPE = block(YetsomeotherbackroomsmodModBlocks.COPPER_PIPE);
	public static final RegistryObject<Item> CONNECTED_COPPER_PIPE = block(YetsomeotherbackroomsmodModBlocks.CONNECTED_COPPER_PIPE);
	public static final RegistryObject<Item> BACKPACK = REGISTRY.register("backpack", () -> new BackpackItem());
	public static final RegistryObject<Item> TANNED_LEATHER = REGISTRY.register("tanned_leather", () -> new TannedLeatherItem());

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
