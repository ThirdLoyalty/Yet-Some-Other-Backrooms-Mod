
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.yetsomeotherbackroomsmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.extensions.IForgeMenuType;

import net.minecraft.world.inventory.MenuType;

import net.mcreator.yetsomeotherbackroomsmod.world.inventory.BackpackInventoryMenu;
import net.mcreator.yetsomeotherbackroomsmod.YetsomeotherbackroomsmodMod;

public class YetsomeotherbackroomsmodModMenus {
	public static final DeferredRegister<MenuType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.MENU_TYPES, YetsomeotherbackroomsmodMod.MODID);
	public static final RegistryObject<MenuType<BackpackInventoryMenu>> BACKPACK_INVENTORY = REGISTRY.register("backpack_inventory", () -> IForgeMenuType.create(BackpackInventoryMenu::new));
}
