
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.yetsomeotherbackroomsmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.mcreator.yetsomeotherbackroomsmod.YetsomeotherbackroomsmodMod;

public class YetsomeotherbackroomsmodModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, YetsomeotherbackroomsmodMod.MODID);
	public static final RegistryObject<CreativeModeTab> BACKROOMS = REGISTRY.register("backrooms",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.yetsomeotherbackroomsmod.backrooms")).icon(() -> new ItemStack(YetsomeotherbackroomsmodModBlocks.LEVEL_0_BOTTOM_WALL.get())).displayItems((parameters, tabData) -> {
				tabData.accept(YetsomeotherbackroomsmodModBlocks.LEVEL_0_BOTTOM_WALL.get().asItem());
				tabData.accept(YetsomeotherbackroomsmodModBlocks.LEVEL_0_WALL.get().asItem());
				tabData.accept(YetsomeotherbackroomsmodModBlocks.LEVEL_0_FLOOR.get().asItem());
				tabData.accept(YetsomeotherbackroomsmodModBlocks.LEVEL_0_CEILING.get().asItem());
				tabData.accept(YetsomeotherbackroomsmodModBlocks.LEVEL_0_LIGHT.get().asItem());
				tabData.accept(YetsomeotherbackroomsmodModBlocks.LOOT_BARREL.get().asItem());
				tabData.accept(YetsomeotherbackroomsmodModBlocks.IRON_VENT.get().asItem());
				tabData.accept(YetsomeotherbackroomsmodModBlocks.LEVEL_RUN_LIGHT.get().asItem());
				tabData.accept(YetsomeotherbackroomsmodModBlocks.POOLROOMS_TILE.get().asItem());
				tabData.accept(YetsomeotherbackroomsmodModBlocks.LEVEL_0_DIRTY_FLOOR.get().asItem());
				tabData.accept(YetsomeotherbackroomsmodModBlocks.METAL_BLOCK.get().asItem());
				tabData.accept(YetsomeotherbackroomsmodModBlocks.METAL_PIPE_BARS.get().asItem());
				tabData.accept(YetsomeotherbackroomsmodModBlocks.LEVEL_4_WALL.get().asItem());
				tabData.accept(YetsomeotherbackroomsmodModBlocks.LEVEL_4_LIGHT.get().asItem());
				tabData.accept(YetsomeotherbackroomsmodModBlocks.LEVEL_4_WALL_2.get().asItem());
				tabData.accept(YetsomeotherbackroomsmodModBlocks.LEVEL_1_PILLAR.get().asItem());
				tabData.accept(YetsomeotherbackroomsmodModBlocks.DARKER_POOLROOMS_TILE.get().asItem());
				tabData.accept(YetsomeotherbackroomsmodModBlocks.PARTY_FLOOR.get().asItem());
				tabData.accept(YetsomeotherbackroomsmodModItems.ALMOND_WATER.get());
				tabData.accept(YetsomeotherbackroomsmodModItems.EMPTY_ALMOND_WATER_CAN.get());
				tabData.accept(YetsomeotherbackroomsmodModItems.LIQUID_PAIN.get());
				tabData.accept(YetsomeotherbackroomsmodModItems.CROWBAR.get());
				tabData.accept(YetsomeotherbackroomsmodModItems.ROCK.get());
				tabData.accept(YetsomeotherbackroomsmodModItems.PURIFIED_WATER_BOTTLE.get());
				tabData.accept(YetsomeotherbackroomsmodModBlocks.COPPER_PIPE.get().asItem());
				tabData.accept(YetsomeotherbackroomsmodModItems.BACKPACK.get());
				tabData.accept(YetsomeotherbackroomsmodModItems.TANNED_LEATHER.get());
			})

					.build());
}
