
package net.mcreator.yetsomeotherbackroomsmod.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class EmptyAlmondWaterCanItem extends Item {
	public EmptyAlmondWaterCanItem() {
		super(new Item.Properties().stacksTo(4).rarity(Rarity.COMMON));
	}
}
