
package net.mcreator.yetsomeotherbackroomsmod.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class TannedLeatherItem extends Item {
	public TannedLeatherItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.COMMON));
	}
}
