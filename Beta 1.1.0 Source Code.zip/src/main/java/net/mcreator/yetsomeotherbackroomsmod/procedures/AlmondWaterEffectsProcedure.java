package net.mcreator.yetsomeotherbackroomsmod.procedures;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;

import net.mcreator.yetsomeotherbackroomsmod.network.YetsomeotherbackroomsmodModVariables;

public class AlmondWaterEffectsProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
			_entity.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, 1200, 1));
		if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
			_entity.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 80, 2));
		if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
			_entity.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 600, 0));
		if (entity instanceof LivingEntity _entity)
			_entity.removeEffect(MobEffects.BLINDNESS);
		if (entity instanceof LivingEntity _entity)
			_entity.removeEffect(MobEffects.DARKNESS);
		if (entity instanceof LivingEntity _entity)
			_entity.removeEffect(MobEffects.HARM);
		if (entity instanceof LivingEntity _entity)
			_entity.removeEffect(MobEffects.POISON);
		if (entity instanceof LivingEntity _entity)
			_entity.removeEffect(MobEffects.WITHER);
		if ((entity.getCapability(YetsomeotherbackroomsmodModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new YetsomeotherbackroomsmodModVariables.PlayerVariables())).thirst <= 20) {
			{
				double _setval = (entity.getCapability(YetsomeotherbackroomsmodModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new YetsomeotherbackroomsmodModVariables.PlayerVariables())).thirst + 5;
				entity.getCapability(YetsomeotherbackroomsmodModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.thirst = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
		} else {
			{
				double _setval = 20;
				entity.getCapability(YetsomeotherbackroomsmodModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.thirst = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
		}
	}
}
