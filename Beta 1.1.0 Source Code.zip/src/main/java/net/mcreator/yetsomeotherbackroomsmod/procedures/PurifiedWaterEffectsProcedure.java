package net.mcreator.yetsomeotherbackroomsmod.procedures;

import net.minecraft.world.entity.Entity;

import net.mcreator.yetsomeotherbackroomsmod.network.YetsomeotherbackroomsmodModVariables;

public class PurifiedWaterEffectsProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if ((entity.getCapability(YetsomeotherbackroomsmodModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new YetsomeotherbackroomsmodModVariables.PlayerVariables())).thirst <= 20) {
			{
				double _setval = (entity.getCapability(YetsomeotherbackroomsmodModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new YetsomeotherbackroomsmodModVariables.PlayerVariables())).thirst + 6;
				entity.getCapability(YetsomeotherbackroomsmodModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.thirst = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
		} else {
			{
				double _setval = 20;
				entity.getCapability(YetsomeotherbackroomsmodModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.thirst = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
		}
	}
}
