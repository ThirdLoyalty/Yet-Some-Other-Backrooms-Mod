package net.mcreator.yetsomeotherbackroomsmod.procedures;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.TickEvent;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.GameType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.core.registries.Registries;
import net.minecraft.client.Minecraft;

import net.mcreator.yetsomeotherbackroomsmod.network.YetsomeotherbackroomsmodModVariables;
import net.mcreator.yetsomeotherbackroomsmod.YetsomeotherbackroomsmodMod;

import javax.annotation.Nullable;

@Mod.EventBusSubscriber
public class ThirstBarOnPlayerTickUpdateProcedure {
	@SubscribeEvent
	public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
		if (event.phase == TickEvent.Phase.END) {
			execute(event, event.player.level(), event.player);
		}
	}

	public static void execute(LevelAccessor world, Entity entity) {
		execute(null, world, entity);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, Entity entity) {
		if (entity == null)
			return;
		if (new Object() {
			public boolean checkGamemode(Entity _ent) {
				if (_ent instanceof ServerPlayer _serverPlayer) {
					return _serverPlayer.gameMode.getGameModeForPlayer() == GameType.SURVIVAL;
				} else if (_ent.level().isClientSide() && _ent instanceof Player _player) {
					return Minecraft.getInstance().getConnection().getPlayerInfo(_player.getGameProfile().getId()) != null && Minecraft.getInstance().getConnection().getPlayerInfo(_player.getGameProfile().getId()).getGameMode() == GameType.SURVIVAL;
				}
				return false;
			}
		}.checkGamemode(entity) || new Object() {
			public boolean checkGamemode(Entity _ent) {
				if (_ent instanceof ServerPlayer _serverPlayer) {
					return _serverPlayer.gameMode.getGameModeForPlayer() == GameType.ADVENTURE;
				} else if (_ent.level().isClientSide() && _ent instanceof Player _player) {
					return Minecraft.getInstance().getConnection().getPlayerInfo(_player.getGameProfile().getId()) != null && Minecraft.getInstance().getConnection().getPlayerInfo(_player.getGameProfile().getId()).getGameMode() == GameType.ADVENTURE;
				}
				return false;
			}
		}.checkGamemode(entity)) {
			if ((entity.isSwimming() || entity.isSprinting()) && (entity.getDeltaMovement().x() != 0 || entity.getDeltaMovement().y() != 0 || entity.getDeltaMovement().z() != 0)) {
				if ((entity.getCapability(YetsomeotherbackroomsmodModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new YetsomeotherbackroomsmodModVariables.PlayerVariables())).thirstTimer > 0) {
					{
						double _setval = (entity.getCapability(YetsomeotherbackroomsmodModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new YetsomeotherbackroomsmodModVariables.PlayerVariables())).thirstTimer - 1;
						entity.getCapability(YetsomeotherbackroomsmodModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
							capability.thirstTimer = _setval;
							capability.syncPlayerVariables(entity);
						});
					}
				} else {
					{
						double _setval = 600;
						entity.getCapability(YetsomeotherbackroomsmodModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
							capability.thirstTimer = _setval;
							capability.syncPlayerVariables(entity);
						});
					}
					if ((entity.getCapability(YetsomeotherbackroomsmodModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new YetsomeotherbackroomsmodModVariables.PlayerVariables())).thirst > 0) {
						{
							double _setval = (entity.getCapability(YetsomeotherbackroomsmodModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new YetsomeotherbackroomsmodModVariables.PlayerVariables())).thirst - 1;
							entity.getCapability(YetsomeotherbackroomsmodModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
								capability.thirst = _setval;
								capability.syncPlayerVariables(entity);
							});
						}
					}
				}
			} else if (entity.getDeltaMovement().x() != 0 || entity.getDeltaMovement().y() != 0 || entity.getDeltaMovement().z() != 0) {
				if ((entity.getCapability(YetsomeotherbackroomsmodModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new YetsomeotherbackroomsmodModVariables.PlayerVariables())).thirstTimer > 0) {
					{
						double _setval = (entity.getCapability(YetsomeotherbackroomsmodModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new YetsomeotherbackroomsmodModVariables.PlayerVariables())).thirstTimer - 0.5;
						entity.getCapability(YetsomeotherbackroomsmodModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
							capability.thirstTimer = _setval;
							capability.syncPlayerVariables(entity);
						});
					}
				} else {
					{
						double _setval = 600;
						entity.getCapability(YetsomeotherbackroomsmodModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
							capability.thirstTimer = _setval;
							capability.syncPlayerVariables(entity);
						});
					}
					if ((entity.getCapability(YetsomeotherbackroomsmodModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new YetsomeotherbackroomsmodModVariables.PlayerVariables())).thirst > 0) {
						{
							double _setval = (entity.getCapability(YetsomeotherbackroomsmodModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new YetsomeotherbackroomsmodModVariables.PlayerVariables())).thirst - 1;
							entity.getCapability(YetsomeotherbackroomsmodModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
								capability.thirst = _setval;
								capability.syncPlayerVariables(entity);
							});
						}
					}
				}
			}
			YetsomeotherbackroomsmodMod.queueServerWork(40, () -> {
				if (Mth.nextInt(RandomSource.create(), 1, 10) == 1) {
					if ((entity.getCapability(YetsomeotherbackroomsmodModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new YetsomeotherbackroomsmodModVariables.PlayerVariables())).thirst == 0) {
						entity.hurt(new DamageSource(world.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(DamageTypes.GENERIC)), 1);
					}
				}
			});
		}
	}
}
